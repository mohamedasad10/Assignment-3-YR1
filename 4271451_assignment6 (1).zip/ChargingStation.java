import java.util.Arrays;

public class ChargingStation implements Dockable {
    String name;
    int num;
    ChargingStation(String name,int num) {   //constructor
        this.name = name;
        this.num = num;
    }

    String Vehicle;
    public Vehicle other;
    private int[] arrVehicle= new int[5];

    @Override
    public boolean canDock() {
        if(arrVehicle[0] == 0){
            return true;
        }else{
            return false;
        }
    }

    @Override
    public int dock(String Vehicle) {
        this.Vehicle = Vehicle;

        arrVehicle[0]= Integer.parseInt(Vehicle);
        System.out.println(Arrays.asList(arrVehicle).indexOf(Vehicle));


        if(arrVehicle[0] == 0){
            arrVehicle[0] = Integer.parseInt(Vehicle);

            return Arrays.asList(arrVehicle).indexOf(Vehicle); //charging port number

        }else{
            return -1;
        }
    }


    public void printInfo(){
        System.out.println("Name: " + name);

        if(arrVehicle[0] == 0){
            System.out.println("Docked Vehicles: ");
            System.out.println("none");
        }

    }

    double maxChargeCapacity;
    double chargeRemaining;

    public int calculateTotalChargeNeeded(){

        System.out.println("Charge needed: ");

        if(arrVehicle[0] == 1 && maxChargeCapacity < 500 && chargeRemaining == 200){
            return 300;
        }

        if(arrVehicle[0] == 2 && maxChargeCapacity < 500 && chargeRemaining == 100){
            return 800;
        }
        return 0;
    }

    public int dock(TestVehicle dragon) {
        return 0;
    }
}

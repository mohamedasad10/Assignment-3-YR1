

public interface Dockable {

    public boolean canDock();

    public int dock(String Vehicle);
}

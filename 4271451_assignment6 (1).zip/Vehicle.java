public abstract class Vehicle {
    private String name;
    protected double chargeRemaining;
    protected double maxChargeCapacity;

    public void setChargeRemaining(double chargeRemaining){
        this.chargeRemaining = chargeRemaining;
    }

    public void setMaxChargeCapacity(double maxChargeCapacity){
        this.maxChargeCapacity = maxChargeCapacity;
    }


    abstract void printInfo();
    abstract double calculateTotalChargeNeeded();
}

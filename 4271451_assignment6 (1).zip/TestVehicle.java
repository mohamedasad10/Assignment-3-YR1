public class TestVehicle extends Vehicle{
    String name;
    int num;

    TestVehicle(String name, int num){
        this.name = name;
        this.num = num;

    }
    @Override
    void printInfo() {
        System.out.println("Name: " + name);
        System.out.println("Charge needed: " + maxChargeCapacity);
    }

    @Override
    double calculateTotalChargeNeeded() {
        return maxChargeCapacity - chargeRemaining;
    }
}
